import {Component} from '@angular/core';
import {ProductService} from './product.service';

@Component({
    selector:'productserv',
templateUrl:'./app/useproductservice.html' //,
 //providers:[ProductService]
})
export class UseServiceInProduct{

productReceived:string ="";
productToBeAdded:string="";
// DI
constructor(private serviceObj:ProductService){

}

GetProduct(){
        // service obj & call getRandomProduct()
     this.productReceived =   this.serviceObj.getRandomProduct();
}


AddProduct(){
    this.serviceObj.insertNewProduct(this.productToBeAdded);
}


}