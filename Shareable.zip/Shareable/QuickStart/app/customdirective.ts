
import {Directive,ElementRef,Input,HostListener} from '@angular/core';

@Directive({
    selector:'[poststyle]'
})
export default class HoverDirective{
    @Input('postcolor') passedColor:string = "lightgreen";

    constructor(private refElement:ElementRef){
    }
    ngOnInit(){
        // this.refElement.nativeElement.style.backgroundColor = this.passedColor;
        this.refElement.nativeElement.style.border = "2px solid red";
        this.refElement.nativeElement.style.borderRadius = "5px";
        this.refElement.nativeElement.style.margin = "5px";
    }

    @HostListener('mouseenter') onmouseenter(){
        this.refElement.nativeElement.style.backgroundColor = "orange";
    }

     @HostListener('mouseleave') onmouseleave(){
        this.refElement.nativeElement.style.backgroundColor = "lightyellow";
    }
}