"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CProduct = (function () {
    function CProduct(name, price, quantity, availability, rating, imageUrl, launchdate, description) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.availability = availability;
        this.rating = rating;
        this.imageUrl = imageUrl;
        this.launchdate = launchdate;
        this.description = description;
        this.description = this.description || "";
    }
    return CProduct;
}());
exports.default = CProduct;
//# sourceMappingURL=CProduct.js.map