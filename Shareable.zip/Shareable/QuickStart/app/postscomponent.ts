import {Component} from '@angular/core';
import {PostsService} from './postsService';

@Component({
    selector:'posts',
    template:`<h1> Posts </h1>
            <ul>
                <li poststyle  *ngFor="let post of postsData">
                  <a [routerLink]='["/post",post.id]'>  {{post.title}} </a>
                </li>
            </ul>
    
    `,
    providers:[PostsService]
})
export class PostsComponent{
    postsData:any = [];
    constructor(private postServObj:PostsService){
        // this.postServObj.getPosts(function(responseFromService:any){
        //     console.log('Data received in Component !')
        //     console.log(responseFromService);
        // });

        let aPromise =this.postServObj.getPosts();
        aPromise.then(
            (response)=>{
                this.postsData = response.json();

            },(error)=>{
                console.log('Rejected..');
                console.log('Something went wrong : ' + error);
        }); // eof then
    }
}