import {Component} from '@angular/core';
import {ActivatedRoute} from '@angular/router';

@Component({
    selector:'postdetails',
    template: `
    <h1> Post Details Component for Post Id : {{postId}} </h1>
    `
})
export class PostDetailComponent{
    postId:number;
    constructor(private currRoute:ActivatedRoute){
    }
    ngOnInit(){
        this.currRoute.params.subscribe(
            r => {
                 this.postId =  +(r["id"])
            }
        )
    }
}