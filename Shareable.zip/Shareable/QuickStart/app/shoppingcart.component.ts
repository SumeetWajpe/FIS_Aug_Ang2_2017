import {Component,Input} from '@angular/core';
import CProduct from './CProduct';

@Component({
    selector:'shoppingcart',
    template:`
     <div>
    <div *ngFor="let p of products" class="ProductDetails">
      <product [pdetails]="p" ></product>
    </div>
  </div>   
     ` 
})
export class ShoppingCartComponent{
    products:CProduct[]= [
        new CProduct("Laptop",40000,100,true,5,'http://ssl-product-images.www8-hp.com/digmedialib/prodimg/lowres/c05059975.png',new Date(),`As a best practice, we highly recommend using the <button> element whenever possible to ensure matching cross-browser rendering.

Among other things, there's a bug in Firefox <30 that prevents us from setting the line-height of <input>-based buttons, causing them to not exactly match the height of other buttons on Firefox.`),
        new CProduct("Mobile",20000,1000,true,4.785,'http://g-ecx.images-amazon.com/images/I/916DWoHhEAL.AC_AA200.jpg',new Date(),`As a best practice, we highly recommend using the <button> element whenever possible to ensure matching cross-browser rendering.

Among other things, there's a bug in Firefox <30 that prevents us from setting the line-height of <input>-based buttons, causing them to not exactly match the height of other buttons on Firefox.`),
        new CProduct("Sofa Set",40000,10,false,4,'https://images2.roomstogo.com/is/image/roomstogo/lr_sof_8503378p_newportcove_cardinal~Cindy-Crawford-Home-Newport-Cove-Cardinal-Sofa.jpeg?$PDP_Primary_936x650$'),
        new CProduct("Shoes",4000,100,true,3,'https://m.media-amazon.com/images/G/01/zappos/melody/landingpages/trendingcats/Trending_Categories_08._V506501652_.jpg'),
        new CProduct("Cricket Bat",40000,600,true,3.5,'https://rukminim1.flixcart.com/image/1408/1408/j391ifk0/bat/x/c/f/900-1100-harrow-kelvin-kb42-mdn-original-imaeagcfgb7xswe9.jpeg?q=90')
        
        
    ]
}