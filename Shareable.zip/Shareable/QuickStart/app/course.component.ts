import {Component,Input} from '@angular/core';

@Component({
    selector:'course',
    template:`<h1> {{coursedetails.name}}  </h1>
     Price : <b> {{coursedetails.price}} </b><br/>
     Date : <b> {{coursedetails.date}} </b><br/>
     Duration : <b> {{coursedetails.duration}} </b><br/>    
     
     ` 
})
export class CourseComponent{
 @Input('details')   coursedetails:any={};
}