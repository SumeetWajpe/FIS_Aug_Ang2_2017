export default class CProduct{
    
    constructor(
        public name:string,
        public price:number,
        public quantity:number,
        public availability:boolean,
        public rating:number,
        public imageUrl:string,
        public launchdate?:Date,        
        public description?:string        
    ){
        this.description = this.description || "";
    }
}