"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var CProduct_1 = require("./CProduct");
var ShoppingCartComponent = (function () {
    function ShoppingCartComponent() {
        this.products = [
            new CProduct_1.default("Laptop", 40000, 100, true, 5, 'http://ssl-product-images.www8-hp.com/digmedialib/prodimg/lowres/c05059975.png', new Date(), "As a best practice, we highly recommend using the <button> element whenever possible to ensure matching cross-browser rendering.\n\nAmong other things, there's a bug in Firefox <30 that prevents us from setting the line-height of <input>-based buttons, causing them to not exactly match the height of other buttons on Firefox."),
            new CProduct_1.default("Mobile", 20000, 1000, true, 4.785, 'http://g-ecx.images-amazon.com/images/I/916DWoHhEAL.AC_AA200.jpg', new Date(), "As a best practice, we highly recommend using the <button> element whenever possible to ensure matching cross-browser rendering.\n\nAmong other things, there's a bug in Firefox <30 that prevents us from setting the line-height of <input>-based buttons, causing them to not exactly match the height of other buttons on Firefox."),
            new CProduct_1.default("Sofa Set", 40000, 10, false, 4, 'https://images2.roomstogo.com/is/image/roomstogo/lr_sof_8503378p_newportcove_cardinal~Cindy-Crawford-Home-Newport-Cove-Cardinal-Sofa.jpeg?$PDP_Primary_936x650$'),
            new CProduct_1.default("Shoes", 4000, 100, true, 3, 'https://m.media-amazon.com/images/G/01/zappos/melody/landingpages/trendingcats/Trending_Categories_08._V506501652_.jpg'),
            new CProduct_1.default("Cricket Bat", 40000, 600, true, 3.5, 'https://rukminim1.flixcart.com/image/1408/1408/j391ifk0/bat/x/c/f/900-1100-harrow-kelvin-kb42-mdn-original-imaeagcfgb7xswe9.jpeg?q=90')
        ];
    }
    return ShoppingCartComponent;
}());
ShoppingCartComponent = __decorate([
    core_1.Component({
        selector: 'shoppingcart',
        template: "\n     <div>\n    <div *ngFor=\"let p of products\" class=\"ProductDetails\">\n      <product [pdetails]=\"p\" ></product>\n    </div>\n  </div>   \n     "
    })
], ShoppingCartComponent);
exports.ShoppingCartComponent = ShoppingCartComponent;
//# sourceMappingURL=shoppingcart.component.js.map