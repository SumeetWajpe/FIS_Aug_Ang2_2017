import {Component,Input} from '@angular/core';
import CProduct from './CProduct';
@Component({
    selector:'product',    
    template:`
    <h1> {{productdetails.name | uppercase}}  </h1>

     <img [src]="productdetails.imageUrl" height="100px" width="100px" style="border:2px solid red;border-radius:5px" /><br/>

     Price : <b> {{productdetails.price | currency:'INR':true }} </b><br/>
     Rating : <b> {{productdetails.rating | number:'1.1-2'}} </b><br/>
     Quantity : <b> {{productdetails.quantity}} </b><br/>    
    Date: <b> {{productdetails.launchdate | date:'short'}} </b><br/>
    Desc : <b> {{productdetails.description | cutshort }} </b>
    
     ` 
})
export class ProductComponent{
 @Input('pdetails')   productdetails:any;
}