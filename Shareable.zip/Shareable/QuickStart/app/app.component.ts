import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  //template:`<shoppingcart></shoppingcart>`
  // template:`<productserv></productserv>
  // <productserv></productserv>`
  //template:`<posts></posts>`
  template:`
    <h1> Using Routing ! </h1>

    <a routerLink="/posts" class="btn btn-primary"> Posts </a>
    <a routerLink="/cart" class="btn btn-primary"> Shopping Cart </a>
    

    <router-outlet></router-outlet>
    
      `
  
})
export class AppComponent  { 
 
 }
