export class ProductService{

products:string[] = ['Mobile','TV','Laptop','Palmtop'];

getAllProducts():string[]{
    return this.products;
}

getRandomProduct():string{    
    return this.products[Math.floor(Math.random() * this.products.length)];
}

insertNewProduct(newProduct:string){
    this.products.push(newProduct);
}
    
}