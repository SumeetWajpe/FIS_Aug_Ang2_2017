import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template:`


  <div>
    <div *ngFor="let c of courses">
      <course [details]="c" ></course>
    </div>
  </div>


  <!--<course name="KnockOut JS !"></course>
  <course name="Node JS !"></course>
  <course></course> -->
 `
//   template: `<h1>Hello {{name}}</h1>
//   <img src={{imageUrl}} height="100px" width="200px" />
//   <img [src]="imageUrl" height="100px" width="200px" />
//   <input type="button" class="btn btn-success" value="Bootstraped !" />

//   <br/>


// <!-- Is Success ? : <input type="checkbox"
// [checked]="isSuccess"
// (change)="OnChangeHandler($event)"
//  /> -->

//  Is Success ? : <input type="checkbox"
// [(ngModel)]="isSuccess"
//  />

//  <!-- <input type="textbox" [value]="name"
//   (input)="OnTextChange($event)" /> -->

//   <input type="textbox" [(ngModel)]="name" />

//   <input type="button" class="btn"
//   [class.btn-success]="isSuccess"
//    value="Bootstraped !" />

//    <input type="button"
//    [style.backgroundColor] = "isSuccess ? 'green' : 'red'"
//    value="Styled Button !"
//    />

//   `,
})
export class AppComponent  { 
  //course1:string="ReactJS !"
  courses:any[]=[{
    name:'Angular 2.0',
    price:3000,
    duration:'3 days',
    date:'31/07/2017'
},
{
    name:'React JS',
    price:4000,
    duration:'3 days',
    date:'1/08/2017'
},
{
    name:'Node JS',
    price:8000,
    duration:'2 days',
    date:'1/08/2017'
},
{
    name:'Backbone JS',
    price:2000,
    duration:'2 days',
    date:'1/08/2017'
}]

  
  name:string = 'Angular JS';
  imageUrl:string = 'https://yellowpencil.com/assets/blog/banners/banner-angularjs.jpg';
  isSuccess:boolean=true;


  OnTextChange(evt:any){
    this.name = evt.target.value;
    
  }
  OnChangeHandler(evt:any){   
    this.isSuccess = evt.target.checked;
  }
 }
