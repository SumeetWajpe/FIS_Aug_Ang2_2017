import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';
import {RouterModule,Routes} from '@angular/router';

import { AppComponent }  from './app.component';
import {CourseComponent} from './course.component';
import {ProductComponent} from './product.component';
import {ShoppingCartComponent} from './shoppingcart.component';
import {UseServiceInProduct} from './useproductservice';
import {PostsComponent} from './postscomponent';
import {PostDetailComponent} from './postdetails.component';

import {ProductService} from './product.service';

import {CutshortPipe} from './cutshort.pipe';
import HoverDirective from './customDirective';

const routes:Routes =[
    {path:'posts',component:PostsComponent},
    {path:'post/:id',component:PostDetailComponent},
    {path:'cart',component:ShoppingCartComponent},
    {path:'',redirectTo:'/posts',pathMatch:'full'},
    {path:'**',redirectTo:'/cart'}
    
];

@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule,RouterModule.forRoot(routes) ],
  declarations: [ AppComponent,CourseComponent,ShoppingCartComponent,ProductComponent,CutshortPipe,UseServiceInProduct,PostsComponent,PostDetailComponent,HoverDirective ],
  bootstrap:    [ AppComponent ],
  providers:[ProductService]
})
export class AppModule { }
