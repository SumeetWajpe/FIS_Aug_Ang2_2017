"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var AppComponent = (function () {
    function AppComponent() {
        //course1:string="ReactJS !"
        this.courses = [{
                name: 'Angular 2.0',
                price: 3000,
                duration: '3 days',
                date: '31/07/2017'
            },
            {
                name: 'React JS',
                price: 4000,
                duration: '3 days',
                date: '1/08/2017'
            },
            {
                name: 'Node JS',
                price: 8000,
                duration: '2 days',
                date: '1/08/2017'
            },
            {
                name: 'Backbone JS',
                price: 2000,
                duration: '2 days',
                date: '1/08/2017'
            }];
        this.name = 'Angular JS';
        this.imageUrl = 'https://yellowpencil.com/assets/blog/banners/banner-angularjs.jpg';
        this.isSuccess = true;
    }
    AppComponent.prototype.OnTextChange = function (evt) {
        this.name = evt.target.value;
    };
    AppComponent.prototype.OnChangeHandler = function (evt) {
        this.isSuccess = evt.target.checked;
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: "\n\n\n  <div>\n    <div *ngFor=\"let c of courses\">\n      <course [details]=\"c\" ></course>\n    </div>\n  </div>\n\n\n  <!--<course name=\"KnockOut JS !\"></course>\n  <course name=\"Node JS !\"></course>\n  <course></course> -->\n "
        //   template: `<h1>Hello {{name}}</h1>
        //   <img src={{imageUrl}} height="100px" width="200px" />
        //   <img [src]="imageUrl" height="100px" width="200px" />
        //   <input type="button" class="btn btn-success" value="Bootstraped !" />
        //   <br/>
        // <!-- Is Success ? : <input type="checkbox"
        // [checked]="isSuccess"
        // (change)="OnChangeHandler($event)"
        //  /> -->
        //  Is Success ? : <input type="checkbox"
        // [(ngModel)]="isSuccess"
        //  />
        //  <!-- <input type="textbox" [value]="name"
        //   (input)="OnTextChange($event)" /> -->
        //   <input type="textbox" [(ngModel)]="name" />
        //   <input type="button" class="btn"
        //   [class.btn-success]="isSuccess"
        //    value="Bootstraped !" />
        //    <input type="button"
        //    [style.backgroundColor] = "isSuccess ? 'green' : 'red'"
        //    value="Styled Button !"
        //    />
        //   `,
    })
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component_old.js.map